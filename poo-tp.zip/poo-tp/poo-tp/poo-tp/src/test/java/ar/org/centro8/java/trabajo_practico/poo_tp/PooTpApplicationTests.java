package ar.org.centro8.java.trabajo_practico.poo_tp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooTpApplicationTests {

	@Test
	void contextLoads() {
	}

}
