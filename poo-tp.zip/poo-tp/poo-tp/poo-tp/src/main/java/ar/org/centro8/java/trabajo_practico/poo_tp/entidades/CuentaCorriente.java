package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaCorriente extends Cuenta {

    private double montoEnDescubierto;
    private Cheque cheque;

    public CuentaCorriente(int numeroCuenta, double saldo, Cliente cliente, double montoEnDescubierto) {
        super(numeroCuenta, saldo, cliente);
        this.montoEnDescubierto = montoEnDescubierto;
    }

    public CuentaCorriente(int numeroCuenta, double saldo, Cliente cliente, double montoEnDescubierto, Cheque cheque) {
        super(numeroCuenta, saldo, cliente);
        this.montoEnDescubierto = montoEnDescubierto;
        this.cheque = cheque;
    }

    public void depositarCheques(Cheque cheque) {
        this.cheque = cheque;
        setSaldo(getSaldo() + cheque.getMonto());
    }

    @Override
    public void depositarEfectivo(double monto) {
        setSaldo(getSaldo() + monto);
    }

    @Override
    public void extraerEfectivo(double monto) {
        if (getSaldo() + montoEnDescubierto >= monto) {
            setSaldo(getSaldo() - monto);
        } else {
            System.out.println("saldo insuficiente");
        }

    }
}
