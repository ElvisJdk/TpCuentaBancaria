package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaCorriente extends Cuenta {

    private double montoEnDescubierto;
    private List<Cheque> cheques = new ArrayList<>();

    public CuentaCorriente(int numeroCuenta, double saldo, Cliente cliente, double montoEnDescubierto) {
        super(numeroCuenta, saldo, cliente);
        this.montoEnDescubierto = montoEnDescubierto;
    }

    public void depositarCheques(Cheque cheque) {
        cheques.add(cheque);
        setSaldo(getSaldo() + cheque.getMonto());
    }

    @Override
    public void depositarEfectivo(double monto) {
        if (monto <= 0) {
            System.out.println("el monto a depositar tiene que ser mayor a 0");
            return;
        }
        setSaldo(getSaldo() + monto);
    }

    @Override
    public void extraerEfectivo(double monto) {
        if (monto <= 0) {
            System.out.println("el monto para extraer efectivo tiene que ser mayor a 0");
            return;
        }
        if (getSaldo() + montoEnDescubierto >= monto) {
            setSaldo(getSaldo() - monto);
        } else {
            System.out.println("saldo insuficiente");
        }

    }
}
