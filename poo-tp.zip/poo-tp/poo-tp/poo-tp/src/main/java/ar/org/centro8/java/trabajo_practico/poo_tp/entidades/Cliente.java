package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.AllArgsConstructor;
import lombok.Data;
@Data
@AllArgsConstructor
public abstract class Cliente {
    private int numeroCliente;
}
