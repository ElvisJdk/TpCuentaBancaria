package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@AllArgsConstructor
@Getter
@Setter
public abstract class Cuenta {
    private int numeroCuenta;
    private double saldo;
    private Cliente cliente;

    public abstract void depositarEfectivo(double monto);

    
    public abstract void extraerEfectivo(double monto);


   

        

}

