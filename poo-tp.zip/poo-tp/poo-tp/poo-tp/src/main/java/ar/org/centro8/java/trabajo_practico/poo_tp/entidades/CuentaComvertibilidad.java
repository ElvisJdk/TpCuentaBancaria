package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString(callSuper = true)
public class CuentaComvertibilidad extends CuentaCorriente {

    private double saldoDolares;
    private double tazaDeConversion;

    public CuentaComvertibilidad(int numeroCuenta, double saldo, Cliente cliente, double montoEnDescubierto,
            double saldoDolares) {
        super(numeroCuenta, saldo, cliente, montoEnDescubierto);
        this.saldoDolares = saldoDolares;
    }

    public CuentaComvertibilidad(int numeroCuenta, double saldo, Cliente cliente, double montoEnDescubierto,
            Cheque cheque, double saldoDolares, double tazaDeConversion) {
        super(numeroCuenta, saldo, cliente, montoEnDescubierto, cheque);
        this.saldoDolares = saldoDolares;
        this.tazaDeConversion = tazaDeConversion;
    }

    public void depositarDodares(double montoDolares) {
        saldoDolares += montoDolares;
    }

    public void extraerDolares(double montoDolares) {
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
        } else {
            System.out.println("saldo insuficiente");
        }

    }

    public void comvertirPesosADolares(double montoPesos) {
        if (montoPesos >= getSaldo()) {
            saldoDolares += montoPesos / tazaDeConversion;
            setSaldo(getSaldo() - montoPesos);
        }else{
            System.out.println("monto insuficiente");
        }
        
    }

    public void comvertirDolaresAPesos(double montoDolares) {
        if (montoDolares >= saldoDolares) {
            saldoDolares -= montoDolares;   
            setSaldo(getSaldo() - montoDolares * tazaDeConversion);
        }else{
            System.out.println("saldo insuficiente");
        }
        
        
    }

}
