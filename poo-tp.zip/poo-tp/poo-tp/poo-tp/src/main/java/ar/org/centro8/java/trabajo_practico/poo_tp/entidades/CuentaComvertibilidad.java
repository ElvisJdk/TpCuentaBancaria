package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)
public class CuentaComvertibilidad extends CuentaCorriente {

    private double saldoDolares;
    private double tazaDeConversion;

    public CuentaComvertibilidad(int numeroCuenta, double saldo, ClienteEmpresa clienteEmpresa,
            double montoEnDescubierto,
            double saldoDolares, double tazaDeConversion) {
        super(numeroCuenta, saldo, clienteEmpresa, montoEnDescubierto);
        this.saldoDolares = saldoDolares;
        this.tazaDeConversion = tazaDeConversion;
    }
    @Override
    public void setCliente(Cliente clienteEmpresa){
        if (clienteEmpresa instanceof ClienteEmpresa) {
            super.setCliente(clienteEmpresa); 
        }else{
            System.out.println("no se puede asignar un cliente que no sea de tipo ClienteEmpresa");
        }
    }

    public void depositarDodares(double montoDolares) {
        if (montoDolares <= 0) {
            System.out.println("el monto para depositar dolares tiene que ser mayor a 0");
            return;
        }
        saldoDolares += montoDolares;
    }

    public void extraerDolares(double montoDolares) {
        if (montoDolares <= 0) {
            System.out.println("el monto para extraer dolares tiene que ser mayor a 0");
            return;
        }
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
        } else {
            System.out.println("Saldo en dolares insuficiente");
        }

    }

    public void comvertirPesosADolares(double montoPesos) {
        if (montoPesos <= 0) {
            System.out.println("el monto para convertir pesos a dolares tiene que ser mayor 0");
            return;
        }
        if (montoPesos <= getSaldo()) {
            saldoDolares += montoPesos / tazaDeConversion;
            setSaldo(getSaldo() - montoPesos);
        } else {
            System.out.println("saldo insuficiente");
        }
    }

    public void comvertirDolaresAPesos(double montoDolares) {
        if (montoDolares <= 0) {
            System.out.println("el monto para convertir dolares a pesos tiene que ser mayor a 0");
            return;
        }
        if (montoDolares <= saldoDolares) {
            saldoDolares -= montoDolares;
            setSaldo(getSaldo() + montoDolares * tazaDeConversion);
        } else {
            System.out.println("saldo en dolares insufientes");
        }

    }

}
