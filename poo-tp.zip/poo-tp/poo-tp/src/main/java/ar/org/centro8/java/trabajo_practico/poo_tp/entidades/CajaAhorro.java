package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper = true)

public class CajaAhorro extends Cuenta {
    private double tazaDeInteres;

    public CajaAhorro(int numeroCuenta, double saldo, Cliente cliente, double tazaDeInteres) {
        super(numeroCuenta, saldo, cliente);
        this.tazaDeInteres = tazaDeInteres;
    }

    public void cobrarInteres() {
        setSaldo(getSaldo() + getSaldo() * tazaDeInteres);
    }

    @Override
    public void depositarEfectivo(double monto) {
        setSaldo(getSaldo() + monto);
    }

    @Override
    public void extraerEfectivo(double monto) {
        if (monto <= getSaldo()) {
            setSaldo(getSaldo() - monto);
        } else {
            System.out.println("saldo insuficiente");
        }

    }
}
