package ar.org.centro8.java.trabajo_practico.poo_tp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooTpApplication {

	public static void main(String[] args) {
		SpringApplication.run(PooTpApplication.class, args);
	}

}
