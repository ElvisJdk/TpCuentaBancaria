package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class ClienteEmpresa extends Cliente {

    private String nombreFantasia;
    private String cuit;
    
    public ClienteEmpresa(int numeroCliente, String nombreFantasia, String cuit) {
        super(numeroCliente);
        this.nombreFantasia = nombreFantasia;
        this.cuit = cuit;
    }

    

   
    

}
