package ar.org.centro8.java.trabajo_practico.poo_tp.entidades;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
@ToString
@Getter
@AllArgsConstructor
public class Cheque {
    private double monto;
    private String bancoEmisor;
    private LocalDate fecha;

}
