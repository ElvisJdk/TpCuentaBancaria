package ar.org.centro8.java.trabajo_practico.poo_tp.test;

import java.time.LocalDate;

import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.CajaAhorro;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.Cheque;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.Cliente;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.ClienteEmpresa;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.ClienteIndividual;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.CuentaComvertibilidad;
import ar.org.centro8.java.trabajo_practico.poo_tp.entidades.CuentaCorriente;

public class TestPrueba {
    public static void main(String[] args) {
        System.out.println("test cuenta corriente");

        Cliente ct1 = new ClienteIndividual(1, "elvis", "morales", "42215457");
        CuentaCorriente cuentaCorriente = new CuentaCorriente(2, 1234, ct1, 12);
        cuentaCorriente.depositarEfectivo(1000);
        cuentaCorriente.extraerEfectivo(500);
        Cheque che = new Cheque(200, "maicra", LocalDate.now());
        cuentaCorriente.depositarCheques(che);
        System.out.println(cuentaCorriente);

        System.out.println("///////////////////////////////////////////////////////////////////////////////////////");
        System.out.println("test caja de ahorro");

        Cliente ct2 = new ClienteIndividual(2, "pepito", "lito", "45445543");
        CajaAhorro cajaAhorro = new CajaAhorro(12, 20, ct2, 10);
        cajaAhorro.depositarEfectivo(20);
        cajaAhorro.extraerEfectivo(200);
        cajaAhorro.cobrarInteres();
        System.out.println(cajaAhorro);


        System.out.println("//////////////////////////////////////////////////////////////////////////////////////////");
        System.out.println("test cuentaCovertibilidad");

        Cliente ct3 = new ClienteEmpresa(3, "steam", "20422154575");
        CuentaComvertibilidad comvertibilidad = new CuentaComvertibilidad(3, 10000, ct3, 100, 150);
        System.out.println(comvertibilidad);
        comvertibilidad.comvertirDolaresAPesos(10);
        System.out.println(comvertibilidad);
        comvertibilidad.comvertirPesosADolares(1000);
        System.out.println(comvertibilidad);

    }
}
